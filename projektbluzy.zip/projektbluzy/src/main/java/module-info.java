module com.example.projektbluzy {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.example.projektbluzy to javafx.fxml;
    exports com.example.projektbluzy;
}